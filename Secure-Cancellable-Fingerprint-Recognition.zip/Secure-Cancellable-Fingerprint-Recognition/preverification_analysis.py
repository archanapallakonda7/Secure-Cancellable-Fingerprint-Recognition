import os
import cv2
import time
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf

from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization, Input, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.applications import MobileNet
from tensorflow.keras.applications.mobilenet import preprocess_input
from tensorflow.keras.regularizers import l2

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report,
    roc_curve,
    auc,
    accuracy_score
)
from sklearn.random_projection import SparseRandomProjection
from sklearn.metrics.pairwise import cosine_similarity

from tensorflow.python.framework.convert_to_constants import convert_variables_to_constants_v2

# =========================================================
# Constants
# =========================================================
IMAGE_SIZE = (200, 200)
BATCH_SIZE = 32
RANDOM_STATE = 42
N_COMPONENTS = 500
BRUTE_FORCE_ATTEMPTS = 10000

np.random.seed(RANDOM_STATE)
random.seed(RANDOM_STATE)
tf.random.set_seed(RANDOM_STATE)

output_dir = "/kaggle/working/"
os.makedirs(output_dir, exist_ok=True)

local_path = "/kaggle/input/datasets/eswarkarridlg/mobileeeee/mobilenet_1_0_224_tf_no_top (3) (1).h5"

# =========================================================
# Subject ID Extraction
# =========================================================
def extract_subject_id(filename):
    """
    Works for common FVC naming styles such as:
    101_1.tif, 1_1.tif, 001_2.tif, etc.
    """
    base = os.path.splitext(filename)[0]
    subject_id = base.split("_")[0]
    return subject_id

# =========================================================
# Self-Transformation Layer
# =========================================================
def apply_slf_transformation_on_features(features):
    features = np.asarray(features, dtype=np.float32)

    norm = np.linalg.norm(features, axis=1, keepdims=True)
    norm[norm == 0] = 1e-8

    normalized_features = features / norm

    return normalized_features

# =========================================================
# Random Projection Cancellable Transformation
# =========================================================
def apply_random_projection_cancellable_transformation(features, n_components=500):
    transformer = SparseRandomProjection(
        n_components=n_components,
        random_state=RANDOM_STATE
    )
    transformed_features = transformer.fit_transform(features)
    return transformed_features

# =========================================================
# Full Cancellable Transformation
# =========================================================
def apply_cancellable_transformation(features):
    slf_features = apply_slf_transformation_on_features(features)
    transformed_features = apply_random_projection_cancellable_transformation(
        slf_features,
        n_components=N_COMPONENTS
    )
    return transformed_features

# =========================================================
# Load and Preprocess Images
# =========================================================
def load_and_preprocess_images(paths_real, paths_altered):

    images = []
    labels = []
    subject_ids = []
    real_indices = []

    real_count = 0
    altered_count = 0

    for root_dir_real in paths_real:
        for subdir, dirs, files in os.walk(root_dir_real):
            for filename in files:
                if filename.upper().endswith(".TIF"):

                    img_path = os.path.join(subdir, filename)
                    img = cv2.imread(img_path)

                    if img is not None:
                        img_resized = cv2.resize(img, IMAGE_SIZE)

                        images.append(img_resized)
                        labels.append(0)
                        subject_ids.append(extract_subject_id(filename))
                        real_indices.append(len(images) - 1)

                        real_count += 1

    print(f"Loaded {real_count} real fingerprint images.")

    for root_dir_altered in paths_altered:
        for subdir, dirs, files in os.walk(root_dir_altered):
            for filename in files:
                if filename.upper().endswith(".TIF"):

                    img_path = os.path.join(subdir, filename)
                    img = cv2.imread(img_path)

                    if img is not None:
                        img_resized = cv2.resize(img, IMAGE_SIZE)

                        images.append(img_resized)
                        labels.append(1)
                        subject_ids.append(extract_subject_id(filename))

                        altered_count += 1

    print(f"Loaded {altered_count} altered fingerprint images.")

    return (
        np.array(images),
        np.array(labels),
        np.array(subject_ids),
        np.array(real_indices)
    )

# =========================================================
# MobileNet Feature Extractor
# =========================================================
def build_mobilenet_feature_extractor(fine_tune=True):

    mobilenet_base = MobileNet(
        weights=local_path,
        include_top=False,
        input_shape=IMAGE_SIZE + (3,)
    )

    if fine_tune:
        for layer in mobilenet_base.layers[-20:]:
            layer.trainable = True
    else:
        for layer in mobilenet_base.layers:
            layer.trainable = False

    model = Sequential([
        mobilenet_base,
        Flatten()
    ])

    return model

def extract_features_mobilenet(images):

    mobilenet_model = build_mobilenet_feature_extractor(fine_tune=True)

    images = preprocess_input(np.array(images, dtype=np.float32))

    features = mobilenet_model.predict(
        images,
        batch_size=BATCH_SIZE,
        verbose=1
    )

    return features

# =========================================================
# Models
# =========================================================
def build_residual_dense(input_shape, num_classes=1):

    inputs = Input(shape=input_shape)

    x = Dense(512, activation="relu", kernel_regularizer=l2(0.001))(inputs)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)

    x = Dense(256, activation="relu", kernel_regularizer=l2(0.001))(x)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)

    x = Dense(128, activation="relu", kernel_regularizer=l2(0.001))(x)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)

    outputs = Dense(num_classes, activation="sigmoid")(x)

    return Model(inputs, outputs)

def TinySqueezeNet_dense(input_shape, num_classes=1):

    inputs = Input(shape=input_shape)

    x = Dense(512, activation="relu", kernel_regularizer=l2(0.001))(inputs)
    x = Dropout(0.5)(x)

    x = Dense(256, activation="relu", kernel_regularizer=l2(0.001))(x)
    x = Dropout(0.5)(x)

    x = Dense(128, activation="relu", kernel_regularizer=l2(0.001))(x)
    x = Dropout(0.5)(x)

    outputs = Dense(num_classes, activation="sigmoid")(x)

    return Model(inputs, outputs)

def ImprovedTinyEfficientNet_dense(input_shape, num_classes=1):

    inputs = Input(shape=input_shape)

    x = Dense(512, activation="relu", kernel_regularizer=l2(0.001))(inputs)
    x = Dropout(0.5)(x)

    x = Dense(256, activation="relu", kernel_regularizer=l2(0.001))(x)
    x = Dropout(0.5)(x)

    x = Dense(128, activation="relu", kernel_regularizer=l2(0.001))(x)
    x = Dropout(0.5)(x)

    outputs = Dense(num_classes, activation="sigmoid")(x)

    return Model(inputs, outputs)

# =========================================================
# Model Complexity
# =========================================================
def calculate_model_complexity(model, X_sample, model_name):

    params = model.count_params()

    try:
        concrete_func = tf.function(
            lambda inputs: model(inputs)
        ).get_concrete_function(
            tf.TensorSpec([1] + list(X_sample.shape[1:]), tf.float32)
        )

        frozen_func = convert_variables_to_constants_v2(concrete_func)
        graph_def = frozen_func.graph.as_graph_def()

        with tf.Graph().as_default() as graph:
            tf.graph_util.import_graph_def(graph_def, name="")

            run_meta = tf.compat.v1.RunMetadata()
            opts = tf.compat.v1.profiler.ProfileOptionBuilder.float_operation()

            flops = tf.compat.v1.profiler.profile(
                graph=graph,
                run_meta=run_meta,
                cmd="op",
                options=opts
            )

        total_flops = flops.total_float_ops

    except Exception as e:
        print(f"FLOPs calculation failed for {model_name}: {e}")
        total_flops = 0

    sample = X_sample[:1].astype(np.float32)

    start_time = time.time()

    for _ in range(100):
        _ = model.predict(sample, verbose=0)

    end_time = time.time()

    avg_inference_time = ((end_time - start_time) / 100) * 1000

    return {
        "Model": model_name,
        "Parameters": params,
        "FLOPs": total_flops,
        "Avg Inference Time (ms)": avg_inference_time
    }

# =========================================================
# SECTION 5.1 - Brute-Force Attack Simulation
# =========================================================
def cosine_score(a, b):
    score = cosine_similarity(a.reshape(1, -1), b.reshape(1, -1))[0][0]
    normalized_score = (score + 1) / 2
    return normalized_score

def compute_genuine_impostor_scores(real_templates, real_subject_ids):

    genuine_scores = []
    impostor_scores = []

    n = len(real_templates)

    for i in range(n):
        for j in range(i + 1, n):

            score = cosine_score(real_templates[i], real_templates[j])

            if real_subject_ids[i] == real_subject_ids[j]:
                genuine_scores.append(score)
            else:
                impostor_scores.append(score)

    return np.array(genuine_scores), np.array(impostor_scores)

def brute_force_attack_scores(real_templates, num_attempts=10000):

    brute_scores = []

    n, d = real_templates.shape

    template_mean = np.mean(real_templates)
    template_std = np.std(real_templates) + 1e-8

    for _ in range(num_attempts):

        target_idx = np.random.randint(0, n)
        target_template = real_templates[target_idx]

        random_template = np.random.normal(
            loc=template_mean,
            scale=template_std,
            size=d
        )

        score = cosine_score(target_template, random_template)

        brute_scores.append(score)

    return np.array(brute_scores)

def plot_attack_distribution(
    genuine_scores,
    impostor_scores,
    brute_scores,
    dataset_name
):

    plt.figure(figsize=(8, 6))

    plt.hist(
        genuine_scores,
        bins=40,
        alpha=0.55,
        density=False,
        label="Genuine"
    )

    plt.hist(
        impostor_scores,
        bins=40,
        alpha=0.55,
        density=False,
        label="Impostor"
    )

    plt.hist(
        brute_scores,
        bins=40,
        alpha=0.55,
        density=False,
        label="Brute-force attack"
    )

    plt.axvline(
        np.mean(genuine_scores),
        linestyle="--",
        linewidth=2,
        label=f"Genuine mean = {np.mean(genuine_scores):.4f}"
    )

    plt.axvline(
        np.mean(impostor_scores),
        linestyle="--",
        linewidth=2,
        label=f"Impostor mean = {np.mean(impostor_scores):.4f}"
    )

    plt.axvline(
        np.mean(brute_scores),
        linestyle="--",
        linewidth=2,
        label=f"Brute-force mean = {np.mean(brute_scores):.4f}"
    )

    plt.xlabel("Normalized Matching Score")
    plt.ylabel("Frequency")
    plt.title(
        f"Frequency vs Normalized Score under Impostor and Brute-Force Attack ({dataset_name})"
    )

    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()

    save_path = f"{output_dir}{dataset_name}_bruteforce_score_distribution.png"
    plt.savefig(save_path, dpi=300)
    plt.show()

    print(f"Saved attack plot: {save_path}")

def perform_bruteforce_analysis(
    transformed_features,
    subject_ids,
    real_indices,
    dataset_name
):

    print("\n===================================================")
    print(f"SECTION 5.1 - BRUTE-FORCE ATTACK SIMULATION: {dataset_name}")
    print("===================================================")

    real_templates = transformed_features[real_indices]
    real_subject_ids = subject_ids[real_indices]

    genuine_scores, impostor_scores = compute_genuine_impostor_scores(
        real_templates,
        real_subject_ids
    )

    brute_scores = brute_force_attack_scores(
        real_templates,
        num_attempts=BRUTE_FORCE_ATTEMPTS
    )

    print(f"Genuine score count     : {len(genuine_scores)}")
    print(f"Impostor score count    : {len(impostor_scores)}")
    print(f"Brute-force score count : {len(brute_scores)}")

    if len(genuine_scores) == 0:
        print("Warning: No genuine pairs found. Check subject ID extraction.")

    attack_stats = pd.DataFrame([
        {
            "Dataset": dataset_name,
            "Score Type": "Genuine",
            "Mean": np.mean(genuine_scores),
            "Variance": np.var(genuine_scores),
            "Std": np.std(genuine_scores),
            "Min": np.min(genuine_scores),
            "Max": np.max(genuine_scores),
            "Count": len(genuine_scores)
        },
        {
            "Dataset": dataset_name,
            "Score Type": "Impostor",
            "Mean": np.mean(impostor_scores),
            "Variance": np.var(impostor_scores),
            "Std": np.std(impostor_scores),
            "Min": np.min(impostor_scores),
            "Max": np.max(impostor_scores),
            "Count": len(impostor_scores)
        },
        {
            "Dataset": dataset_name,
            "Score Type": "Brute-force",
            "Mean": np.mean(brute_scores),
            "Variance": np.var(brute_scores),
            "Std": np.std(brute_scores),
            "Min": np.min(brute_scores),
            "Max": np.max(brute_scores),
            "Count": len(brute_scores)
        }
    ])

    print("\nAttack Statistics:")
    print(attack_stats)

    attack_stats.to_csv(
        f"{output_dir}{dataset_name}_bruteforce_attack_statistics.csv",
        index=False
    )

    plot_attack_distribution(
        genuine_scores,
        impostor_scores,
        brute_scores,
        dataset_name
    )

    return attack_stats

# =========================================================
# Dataset Paths
# =========================================================
dataset_configs = {
    "FVC2002": {
        "paths_real": [
            "/kaggle/input/datasets/eswarkarridlg/fvcfingerprint/74034_3_En_4_MOESM1_ESM/FVC2002/Dbs/Db1_a",
            "/kaggle/input/datasets/eswarkarridlg/fvcfingerprint/74034_3_En_4_MOESM1_ESM/FVC2002/Dbs/Db1_b",
        ],
        "paths_altered": [
            "/kaggle/working/2002/DB211/blur",
            "/kaggle/working/2002/DB211/distortion",
            "/kaggle/working/2002/DB211/noise",
            "/kaggle/working/2002/DB211/blur"
        ]
    },

    "FVC2004": {
        "paths_real": [
            "/kaggle/input/datasets/eswarkarridlg/fvcfingerprint/74034_3_En_4_MOESM1_ESM/FVC2004/Dbs/DB1_A",
            "/kaggle/input/datasets/eswarkarridlg/fvcfingerprint/74034_3_En_4_MOESM1_ESM/FVC2004/Dbs/DB1_B",
        ],
        "paths_altered": [
            "/kaggle/working/2004/DB211/blur",
            "/kaggle/working/2004/DB211/distortion",
            "/kaggle/working/2004/DB211/noise",
            "/kaggle/working/2004/DB211/blur"
        ]
    }
}

all_attack_statistics = []

# =========================================================
# Run Complete Pipeline Dataset-wise
# =========================================================
for dataset_name, dataset_info in dataset_configs.items():

    print("\n###################################################")
    print(f"Processing Dataset: {dataset_name}")
    print("###################################################")

    paths_real = dataset_info["paths_real"]
    paths_altered = dataset_info["paths_altered"]

    images, labels, subject_ids, real_indices = load_and_preprocess_images(
        paths_real,
        paths_altered
    )

    if len(images) == 0:
        print(f"No images found for {dataset_name}. Skipping.")
        continue

    # =========================================================
    # Feature Extraction
    # =========================================================
    features = extract_features_mobilenet(images)

    # =========================================================
    # Cancellable Transformation
    # =========================================================
    transformed_features = apply_cancellable_transformation(features)

    # =========================================================
    # SECTION 5.1 - Brute-force Attack Analysis
    # =========================================================
    attack_stats = perform_bruteforce_analysis(
        transformed_features,
        subject_ids,
        real_indices,
        dataset_name
    )

    all_attack_statistics.append(attack_stats)

    # =========================================================
    # Train/Test Split
    # =========================================================
    X_train, X_test, y_train, y_test = train_test_split(
        transformed_features,
        labels,
        test_size=0.3,
        shuffle=True,
        random_state=RANDOM_STATE,
        stratify=labels
    )

    input_shape = (X_train.shape[1],)

    early_stopping = EarlyStopping(
        monitor="val_loss",
        patience=10,
        restore_best_weights=True
    )

    # =========================================================
    # Build Models
    # =========================================================
    model4 = build_residual_dense(input_shape, num_classes=1)
    model4.compile(
        optimizer="adam",
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )

    model2 = TinySqueezeNet_dense(input_shape, num_classes=1)
    model2.compile(
        optimizer="adam",
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )

    model3 = ImprovedTinyEfficientNet_dense(input_shape, num_classes=1)
    model3.compile(
        optimizer="adam",
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )

    print("\nModel 1 (Residual Dense) Summary:")
    model4.summary()

    print("\nModel 2 (TinySqueezeNet) Summary:")
    model2.summary()

    print("\nModel 3 (Improved TinyEfficientNet) Summary:")
    model3.summary()

    # =========================================================
    # SECTION 3.8 - Model Complexity Analysis
    # =========================================================
    print("\n===================================================")
    print(f"SECTION 3.8 - MODEL COMPLEXITY ANALYSIS: {dataset_name}")
    print("===================================================")

    complexity_results = []

    complexity_results.append(
        calculate_model_complexity(
            model4,
            X_train.astype(np.float32),
            "Residual Dense"
        )
    )

    complexity_results.append(
        calculate_model_complexity(
            model2,
            X_train.astype(np.float32),
            "TinySqueezeNet Dense"
        )
    )

    complexity_results.append(
        calculate_model_complexity(
            model3,
            X_train.astype(np.float32),
            "Improved TinyEfficientNet Dense"
        )
    )

    complexity_df = pd.DataFrame(complexity_results)

    print("\nTable X. Model Complexity Comparison")
    print(complexity_df)

    complexity_df.to_csv(
        f"{output_dir}{dataset_name}_model_complexity_table.csv",
        index=False
    )

    plt.figure(figsize=(10, 6))
    plt.bar(complexity_df["Model"], complexity_df["Parameters"])
    plt.title(f"Model Parameter Comparison - {dataset_name}")
    plt.xlabel("Models")
    plt.ylabel("Number of Parameters")
    plt.xticks(rotation=10)
    plt.tight_layout()
    plt.savefig(f"{output_dir}{dataset_name}_model_parameters_comparison.png", dpi=300)
    plt.show()

    # =========================================================
    # Train Models
    # =========================================================
    history4 = model4.fit(
        X_train,
        y_train,
        epochs=50,
        batch_size=32,
        validation_data=(X_test, y_test),
        callbacks=[early_stopping],
        shuffle=True
    )

    history2 = model2.fit(
        X_train,
        y_train,
        epochs=50,
        batch_size=32,
        validation_data=(X_test, y_test),
        callbacks=[early_stopping],
        shuffle=True
    )

    history3 = model3.fit(
        X_train,
        y_train,
        epochs=50,
        batch_size=32,
        validation_data=(X_test, y_test),
        callbacks=[early_stopping],
        shuffle=True
    )

    # =========================================================
    # Predictions
    # =========================================================
    outputs2 = model2.predict(X_test)
    outputs3 = model3.predict(X_test)
    outputs4 = model4.predict(X_test)

    preds2 = (outputs2 > 0.5).astype(int)
    preds3 = (outputs3 > 0.5).astype(int)
    preds4 = (outputs4 > 0.5).astype(int)

    print("\nClassification Report for Model 1 (Residual Dense):")
    print(classification_report(y_test, preds4))

    print("\nClassification Report for Model 2 (TinySqueezeNet):")
    print(classification_report(y_test, preds2))

    print("\nClassification Report for Model 3 (Improved TinyEfficientNet):")
    print(classification_report(y_test, preds3))

    # =========================================================
    # Ensemble
    # =========================================================
    ensemble_preds = (outputs2 + outputs3 + outputs4) / 3
    ensemble_preds_classes = (ensemble_preds > 0.5).astype(int)

    ensemble_accuracy = accuracy_score(
        y_test,
        ensemble_preds_classes
    )

    print(f"\nEnsemble Model Accuracy for {dataset_name}: {ensemble_accuracy:.4f}")

    sns.set(style="whitegrid")
    plt.rcParams.update({"font.size": 12})

    # =========================================================
    # Accuracy Plot
    # =========================================================
    def plot_accuracy(history, model_name):

        plt.figure(figsize=(8, 6))

        plt.plot(
            history.history["accuracy"],
            label="Train Accuracy",
            linestyle="--",
            linewidth=2
        )

        plt.plot(
            history.history["val_accuracy"],
            label="Validation Accuracy",
            linestyle="-",
            linewidth=2
        )

        plt.title(f"Training and Validation Accuracy - {model_name} - {dataset_name}")
        plt.xlabel("Epochs")
        plt.ylabel("Accuracy")
        plt.legend(loc="lower right")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(f"{output_dir}{dataset_name}_{model_name}_accuracy.png", dpi=300)
        plt.show()

    plot_accuracy(history4, "Model_1_Residual_Dense")
    plot_accuracy(history2, "Model_2_TinySqueezeNet")
    plot_accuracy(history3, "Model_3_Improved_TinyEfficientNet")

    # =========================================================
    # Loss Plot
    # =========================================================
    def plot_loss(history, model_name):

        plt.figure(figsize=(8, 6))

        plt.plot(
            history.history["loss"],
            label="Train Loss",
            linestyle="--",
            linewidth=2
        )

        plt.plot(
            history.history["val_loss"],
            label="Validation Loss",
            linestyle="-",
            linewidth=2
        )

        plt.title(f"Training and Validation Loss - {model_name} - {dataset_name}")
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.legend(loc="upper right")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(f"{output_dir}{dataset_name}_{model_name}_loss.png", dpi=300)
        plt.show()

    plot_loss(history4, "Model_1_Residual_Dense")
    plot_loss(history2, "Model_2_TinySqueezeNet")
    plot_loss(history3, "Model_3_Improved_TinyEfficientNet")

    # =========================================================
    # EER Plot
    # =========================================================
    def plot_eer(y_true, y_score, model_name):

        fpr, tpr, thresholds = roc_curve(y_true, y_score)
        fnr = 1 - tpr

        eer_index = np.nanargmin(np.absolute(fnr - fpr))
        eer = fpr[eer_index]
        eer_threshold = thresholds[eer_index]

        plt.figure(figsize=(8, 6))

        plt.plot(thresholds, fpr, label="FAR", linewidth=2)
        plt.plot(thresholds, fnr, label="FRR", linewidth=2)

        plt.axvline(
            x=eer_threshold,
            linestyle="--",
            label=f"EER = {eer:.4f}"
        )

        plt.title(f"EER Curve - {model_name} - {dataset_name}")
        plt.xlabel("Decision Threshold")
        plt.ylabel("Error Rate")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(f"{output_dir}{dataset_name}_{model_name}_eer.png", dpi=300)
        plt.show()

        print(f"EER for {model_name} on {dataset_name}: {eer:.4f}")

    plot_eer(y_test, outputs4, "Model_1_Residual_Dense")
    plot_eer(y_test, outputs2, "Model_2_TinySqueezeNet")
    plot_eer(y_test, outputs3, "Model_3_Improved_TinyEfficientNet")
    plot_eer(y_test, ensemble_preds, "Ensemble_Model")

    # =========================================================
    # ROC Curve
    # =========================================================
    def plot_roc_curve(y_true, y_score, model_name):

        fpr, tpr, _ = roc_curve(y_true, y_score)
        roc_auc = auc(fpr, tpr)

        plt.plot(
            fpr,
            tpr,
            label=f"{model_name} AUC = {roc_auc:.4f}",
            linewidth=2
        )

    plt.figure(figsize=(8, 6))

    plot_roc_curve(y_test, outputs4, "Model 1")
    plot_roc_curve(y_test, outputs2, "Model 2")
    plot_roc_curve(y_test, outputs3, "Model 3")
    plot_roc_curve(y_test, ensemble_preds, "Ensemble")

    plt.title(f"ROC Curve - {dataset_name}")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.legend(loc="lower right")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(f"{output_dir}{dataset_name}_ensemble_roc.png", dpi=300)
    plt.show()

# =========================================================
# Combined Attack Statistics Table
# =========================================================
if len(all_attack_statistics) > 0:

    final_attack_statistics = pd.concat(
        all_attack_statistics,
        ignore_index=True
    )

    print("\n===================================================")
    print("FINAL TABLE - BRUTE-FORCE ATTACK STATISTICS")
    print("===================================================")

    print(final_attack_statistics)

    final_attack_statistics.to_csv(
        f"{output_dir}final_bruteforce_attack_statistics_FVC2002_FVC2004.csv",
        index=False
    )