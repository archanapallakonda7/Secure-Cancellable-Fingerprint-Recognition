# =========================================================
# Elegant Brute-Force Attack Visualization
# Compatible with your existing code
# =========================================================

from sklearn.metrics.pairwise import cosine_similarity

def cosine_score_normalized(a, b):
    score = cosine_similarity(a.reshape(1, -1), b.reshape(1, -1))[0][0]
    return (score + 1) / 2


def compute_genuine_impostor_scores(real_templates, real_subject_ids):
    genuine_scores = []
    impostor_scores = []

    n = len(real_templates)

    for i in range(n):
        for j in range(i + 1, n):
            score = cosine_score_normalized(real_templates[i], real_templates[j])

            if real_subject_ids[i] == real_subject_ids[j]:
                genuine_scores.append(score)
            else:
                impostor_scores.append(score)

    return np.array(genuine_scores), np.array(impostor_scores)


def compute_bruteforce_scores(real_templates, num_attempts=10000):
    brute_scores = []

    n, d = real_templates.shape

    template_mean = np.mean(real_templates)
    template_std = np.std(real_templates) + 1e-8

    for _ in range(num_attempts):
        target_idx = np.random.randint(0, n)
        target_template = real_templates[target_idx]

        random_template = np.random.normal(
            loc=template_mean,
            scale=template_std,
            size=d
        )

        score = cosine_score_normalized(target_template, random_template)
        brute_scores.append(score)

    return np.array(brute_scores)


def plot_elegant_bruteforce_distribution(
    genuine_scores,
    impostor_scores,
    brute_scores,
    dataset_name="FVC2002",
    output_dir="/kaggle/working/"
):

    plt.figure(figsize=(9, 6))

    bins = np.linspace(0, 1, 45)

    plt.hist(
        genuine_scores,
        bins=bins,
        density=False,
        alpha=0.55,
        label=f"Genuine μ={np.mean(genuine_scores):.3f}, σ²={np.var(genuine_scores):.5f}",
        edgecolor="black",
        linewidth=0.4
    )

    plt.hist(
        impostor_scores,
        bins=bins,
        density=False,
        alpha=0.55,
        label=f"Impostor μ={np.mean(impostor_scores):.3f}, σ²={np.var(impostor_scores):.5f}",
        edgecolor="black",
        linewidth=0.4
    )

    plt.hist(
        brute_scores,
        bins=bins,
        density=False,
        alpha=0.55,
        label=f"Brute-force μ={np.mean(brute_scores):.3f}, σ²={np.var(brute_scores):.5f}",
        edgecolor="black",
        linewidth=0.4
    )

    plt.axvline(np.mean(genuine_scores), linestyle="--", linewidth=2)
    plt.axvline(np.mean(impostor_scores), linestyle="--", linewidth=2)
    plt.axvline(np.mean(brute_scores), linestyle="--", linewidth=2)

    plt.xlabel("Normalized Matching Score", fontsize=13)
    plt.ylabel("Frequency", fontsize=13)

    plt.title(
        f"Frequency vs. Normalized Score under Impostor and Brute-Force Attack\n{dataset_name}",
        fontsize=14,
        fontweight="bold"
    )

    plt.legend(frameon=True, fontsize=10)
    plt.grid(axis="y", linestyle="--", alpha=0.35)

    plt.tight_layout()

    save_path = f"{output_dir}{dataset_name}_elegant_bruteforce_attack_distribution.png"
    plt.savefig(save_path, dpi=600, bbox_inches="tight")
    plt.show()

    print(f"Saved figure: {save_path}")


def run_elegant_bruteforce_attack_analysis(
    transformed_features,
    subject_ids,
    real_indices,
    dataset_name="FVC2002",
    output_dir="/kaggle/working/",
    num_attempts=10000
):

    real_templates = transformed_features[real_indices]
    real_subject_ids = subject_ids[real_indices]

    genuine_scores, impostor_scores = compute_genuine_impostor_scores(
        real_templates,
        real_subject_ids
    )

    brute_scores = compute_bruteforce_scores(
        real_templates,
        num_attempts=num_attempts
    )

    attack_stats = pd.DataFrame({
        "Dataset": [dataset_name, dataset_name, dataset_name],
        "Score Type": ["Genuine", "Impostor", "Brute-force"],
        "Mean": [
            np.mean(genuine_scores),
            np.mean(impostor_scores),
            np.mean(brute_scores)
        ],
        "Variance": [
            np.var(genuine_scores),
            np.var(impostor_scores),
            np.var(brute_scores)
        ],
        "Std": [
            np.std(genuine_scores),
            np.std(impostor_scores),
            np.std(brute_scores)
        ],
        "Minimum": [
            np.min(genuine_scores),
            np.min(impostor_scores),
            np.min(brute_scores)
        ],
        "Maximum": [
            np.max(genuine_scores),
            np.max(impostor_scores),
            np.max(brute_scores)
        ],
        "Count": [
            len(genuine_scores),
            len(impostor_scores),
            len(brute_scores)
        ]
    })

    print("\nBrute-Force Attack Statistics")
    print(attack_stats)

    attack_stats.to_csv(
        f"{output_dir}{dataset_name}_bruteforce_attack_statistics.csv",
        index=False
    )

    plot_elegant_bruteforce_distribution(
        genuine_scores,
        impostor_scores,
        brute_scores,
        dataset_name=dataset_name,
        output_dir=output_dir
    )

    return attack_stats, genuine_scores, impostor_scores, brute_scores
attack_stats, genuine_scores, impostor_scores, brute_scores = run_elegant_bruteforce_attack_analysis(
    transformed_features=transformed_features,
    subject_ids=subject_ids,
    real_indices=real_indices,
    dataset_name="FVC2002",
    output_dir=output_dir,
    num_attempts=10000
)