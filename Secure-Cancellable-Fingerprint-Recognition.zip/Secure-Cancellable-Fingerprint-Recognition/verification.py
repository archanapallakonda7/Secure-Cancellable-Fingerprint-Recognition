# ============================================================
# Secure Cancellable Fingerprint Recognition
# Verification Protocol using Euclidean Distance
# ============================================================

import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import roc_curve, auc
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.models import Model


# ============================================================
# 1. Configuration
# ============================================================

DATASET_PATH = ""   # change path
IMG_SIZE = (224, 224)

RSLIM_DIM = 512
SPARSITY = 0.30
RANDOM_SEED = 42

np.random.seed(RANDOM_SEED)


# ============================================================
# 2. Load Fingerprint Images
# Folder format:
# data/FVC2002/DB1/
# ├── 001/
# │   ├── 1.tif
# │   ├── 2.tif
# │   ...
# ├── 002/
# ============================================================

def load_fingerprint_dataset(dataset_path):
    images = []
    labels = []
    impression_ids = []

    persons = sorted(os.listdir(dataset_path))

    for person in persons:
        person_path = os.path.join(dataset_path, person)

        if not os.path.isdir(person_path):
            continue

        files = sorted(os.listdir(person_path))

        for file in files:
            if file.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")):
                img_path = os.path.join(person_path, file)

                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                img = cv2.resize(img, IMG_SIZE)

                img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

                images.append(img)
                labels.append(person)

                impression_id = int(os.path.splitext(file)[0])
                impression_ids.append(impression_id)

    images = np.array(images, dtype=np.float32)
    labels = np.array(labels)
    impression_ids = np.array(impression_ids)

    return images, labels, impression_ids


# ============================================================
# 3. MobileNetV2 Feature Extraction
# ============================================================

def build_feature_extractor():
    base_model = MobileNetV2(
        weights="imagenet",
        include_top=False,
        pooling="avg",
        input_shape=(224, 224, 3)
    )

    model = Model(inputs=base_model.input, outputs=base_model.output)
    return model


def extract_features(images, model):
    images = preprocess_input(images)
    features = model.predict(images, batch_size=32, verbose=1)
    return features


# ============================================================
# 4. Feature Scaling
# ============================================================

def scale_features(features):
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)
    return scaled_features, scaler


# ============================================================
# 5. RSLiM: Random Sparse Linear Mapping
# ============================================================

def generate_sparse_projection_matrix(input_dim, output_dim, sparsity=0.30):
    """
    Random Sparse Linear Mapping matrix.
    Entries are mostly zero, with random Gaussian non-zero values.
    """

    S = np.zeros((input_dim, output_dim))

    mask = np.random.rand(input_dim, output_dim) < sparsity
    S[mask] = np.random.normal(0, 1, size=np.sum(mask))

    S = S / np.sqrt(output_dim)

    return S


def apply_rslim(features, projection_matrix):
    protected_templates = np.dot(features, projection_matrix)
    return protected_templates


# ============================================================
# 6. Enrollment-Probe Split
# First 4 impressions = enrollment
# Last 4 impressions = probe
# ============================================================

def create_enrollment_probe_split(templates, labels, impression_ids):
    enrollment = []
    probe = []

    for template, label, imp_id in zip(templates, labels, impression_ids):
        item = {
            "template": template,
            "label": label,
            "impression_id": imp_id
        }

        if imp_id <= 4:
            enrollment.append(item)
        else:
            probe.append(item)

    return enrollment, probe


# ============================================================
# 7. Euclidean Distance Matching
# ============================================================

def euclidean_distance(a, b):
    return np.linalg.norm(a - b)


def generate_scores(enrollment, probe):
    genuine_scores = []
    impostor_scores = []

    for enroll_item in enrollment:
        for probe_item in probe:

            dist = euclidean_distance(
                enroll_item["template"],
                probe_item["template"]
            )

            if enroll_item["label"] == probe_item["label"]:
                genuine_scores.append(dist)
            else:
                impostor_scores.append(dist)

    return np.array(genuine_scores), np.array(impostor_scores)


# ============================================================
# 8. FAR, FRR, EER Calculation
# Lower Euclidean distance = more similar
# ============================================================

def compute_eer(genuine_scores, impostor_scores):
    scores = np.concatenate([genuine_scores, impostor_scores])

    labels = np.concatenate([
        np.ones(len(genuine_scores)),
        np.zeros(len(impostor_scores))
    ])

    # Convert distance to similarity for ROC
    similarity_scores = -scores

    fpr, tpr, thresholds = roc_curve(labels, similarity_scores)
    roc_auc = auc(fpr, tpr)

    fnr = 1 - tpr

    eer_index = np.nanargmin(np.abs(fpr - fnr))
    eer = (fpr[eer_index] + fnr[eer_index]) / 2

    eer_threshold = thresholds[eer_index]

    return eer, roc_auc, fpr, tpr, fnr, eer_threshold


# ============================================================
# 9. Plot ROC Curve
# ============================================================

def plot_roc(fpr, tpr, roc_auc, dataset_name):
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.4f}")
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel("False Acceptance Rate")
    plt.ylabel("True Acceptance Rate")
    plt.title(f"ROC Curve - {dataset_name}")
    plt.legend()
    plt.grid(True)
    plt.show()


# ============================================================
# 10. Plot Genuine and Impostor Score Distributions
# ============================================================

def plot_score_distribution(genuine_scores, impostor_scores, dataset_name):
    plt.figure(figsize=(7, 5))
    plt.hist(genuine_scores, bins=50, alpha=0.6, label="Genuine")
    plt.hist(impostor_scores, bins=50, alpha=0.6, label="Impostor")
    plt.xlabel("Euclidean Distance")
    plt.ylabel("Frequency")
    plt.title(f"Genuine vs Impostor Distance Distribution - {dataset_name}")
    plt.legend()
    plt.grid(True)
    plt.show()


# ============================================================
# 11. Main Execution
# ============================================================

def main():
    dataset_name = os.path.basename(DATASET_PATH)

    print("\nLoading fingerprint dataset...")
    images, labels, impression_ids = load_fingerprint_dataset(DATASET_PATH)

    print("Total images:", len(images))
    print("Total identities:", len(set(labels)))

    label_encoder = LabelEncoder()
    labels = label_encoder.fit_transform(labels)

    print("\nBuilding MobileNetV2 feature extractor...")
    feature_extractor = build_feature_extractor()

    print("\nExtracting MobileNetV2 features...")
    features = extract_features(images, feature_extractor)

    print("Original feature shape:", features.shape)

    print("\nScaling features...")
    scaled_features, scaler = scale_features(features)

    print("\nGenerating RSLiM projection matrix...")
    projection_matrix = generate_sparse_projection_matrix(
        input_dim=scaled_features.shape[1],
        output_dim=RSLIM_DIM,
        sparsity=SPARSITY
    )

    print("\nGenerating cancellable protected templates...")
    protected_templates = apply_rslim(scaled_features, projection_matrix)

    print("Protected template shape:", protected_templates.shape)

    print("\nCreating enrollment-probe split...")
    enrollment, probe = create_enrollment_probe_split(
        protected_templates,
        labels,
        impression_ids
    )

    print("Enrollment templates:", len(enrollment))
    print("Probe templates:", len(probe))

    print("\nGenerating genuine and impostor scores...")
    genuine_scores, impostor_scores = generate_scores(enrollment, probe)

    print("Genuine pairs:", len(genuine_scores))
    print("Impostor pairs:", len(impostor_scores))

    print("\nComputing EER and AUC...")
    eer, roc_auc, fpr, tpr, fnr, eer_threshold = compute_eer(
        genuine_scores,
        impostor_scores
    )

    print("\n================ Verification Results ================")
    print(f"Dataset: {dataset_name}")
    print(f"EER: {eer * 100:.4f}%")
    print(f"ROC-AUC: {roc_auc:.4f}")
    print(f"EER Threshold: {eer_threshold:.4f}")
    print("======================================================")

    plot_roc(fpr, tpr, roc_auc, dataset_name)
    plot_score_distribution(genuine_scores, impostor_scores, dataset_name)


if __name__ == "__main__":
    main()